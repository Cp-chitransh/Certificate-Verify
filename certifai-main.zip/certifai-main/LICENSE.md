## License

Copyright © 2023 Sanskar Omar

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

1. Acknowledge the original author (Sanskar Omar) when using this software.
2. Provide information on where the original material may be obtained: [GitHub Repository](https://github.com/sanskaromar/certificate-generator).
3. You do NOT have to release the source code of your derived work, but it's appreciated if you do.

The software is provided "as is," without warranty of any kind, express or implied, including but not limited to the warranties of merchantability, fitness for a particular purpose, and non-infringement. In no event shall the authors or copyright holders be liable for any claim, damages, or other liability, whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the software or the use or other dealings in the software.