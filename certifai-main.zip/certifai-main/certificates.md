# Certificates
Generated on 09 November 2023, 23:21:20

| id                  | name             | profile_url                                              |
|:--------------------|:-----------------|:---------------------------------------------------------|
| XYZ123AB-MNNITAx001 | Alyssa P. Hacker | [Link](https://youtu.be/dQw4w9WgXcQ?si=pEHw5WQAUl7E0G9c) |
| XYZ123AB-MNNITAx002 | Satoshi Nakamoto | [Link](https://youtu.be/dQw4w9WgXcQ?si=pEHw5WQAUl7E0G9c) |